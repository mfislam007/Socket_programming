// first task of socket programming.This program takes in an IPv4 address
// in dotted decimal format, and the program tells which class this address
// belongs to

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
	if (argc != 2) {
		printf("Usage: %s dotted-decimal-address\n", argv[0]);
		return 1;
	}
	// we shoul analyse the address
	printf("address is %s\n", argv[1]);
	char part1[4] = "\0";
	for (int i = 0; ; i++) {
		if (argv[1][i] != '.') part1[i] = argv[1][i];
		else break;
	}
	int va = atoi(part1);
	if (va >= 0 && va <= 127) printf("Class A\n");
	if (va >= 128 && va <= 191) printf("Class B\n");
	if (va >= 192 && va <= 223) printf("Class C\n");
	if (va >= 224) printf("Unknown Class\n");
	return 0;
}

